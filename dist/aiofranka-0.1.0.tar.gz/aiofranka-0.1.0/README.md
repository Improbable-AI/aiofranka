# aiofranka

This repo contains a minimal version of 

- various control scripts using Franka's torque controllability
- a CPC-HPC style server/client interface for controlling Franka

using the official `pylibfranka` package as a control interface with Franka, and `mujoco` as kinematics/dynamics model. 

## Installation

1. Follow instructions here and install `pylibfranka`.

2. Install extra dependencies;

    ```bash
    pip install mujoco scipy pyzmq
    ```

## How-to-Use 

### 1. Direct Control Setup

```bash
# on real-time kerneled CPC 
python controllers/impedance.py
``` 

I have implemented two basic scripts for controlling the robot;  joint-level impedance controller, and operational-space control, which can (and should) be launched directy on a real-time kerneled PC that is directly connected with Franka. 

- [Operational Space Control](controllers/osc.py)
- [Impedance Controller](controllers/impedance.py)

Based on the controller scripts, feel free to modify however you need. 

### 2. Server-Client Setup  

We often want to decopuple the CPC (Control PC) that communicates with the robot at 1kHZ with real-timeness enforced from the HPC (High-Level PC) where it sends a position/velocity target at slightly lower update frequency (i.e., 50Hz or 100Hz). This setup is especially desirable when the high-level policy commands should be generated using a compute-intensive layer (i.e., neural network policies) requiring GPU acceleration. 

If you want to use it this way, you should 

```bash 
# on real-time kerneled CPC 
python run.py --ip 172.16.0.2
```

and at HPC, you can design your own script like this: 

```python
from franka_server import FrankaServer 

franka.switch_controller("impedance")
franka.move_to([0, 0, 0, -1.57079, 0, 1.57079, -0.7853], duration = 3000)

while True: 
    
    delta = np.random.uniform(-0.1, 0.1, size=7).tolist()
    base = np.array([0, 0, 0, -1.57079, 0, 1.57079, -0.7853])
    target = (base + delta).tolist()
    franka.update_target(target)
```